document.getElementById('generate').addEventListener('click', async () => {
    const catImg = document.getElementById('cat-img');
    const button = document.getElementById('generate');
    try {
        const response = await fetch('https://api.thecatapi.com/v1/images/search');
        const data = await response.json();
        catImg.src = data[0].url;
        catImg.style.display = 'block';
    } catch (error) {
        alert('Не удалось загрузить кота, приходите завтра.');
    }
    const randomColor = `#${Math.floor(Math.random() * 16777215).toString(16)}`;
    button.style.backgroundColor = randomColor;
});
